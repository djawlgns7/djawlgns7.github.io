package kr.bit.controller;

import kr.bit.entity.Board;
import kr.bit.mapper.BoardMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class BoardController {

    private final BoardMapper boardMapper;

    @RequestMapping("/")
    public String home() {
        return "home";
    }

    @RequestMapping("/boardList")
    public @ResponseBody List<Board> boardList() {
        return boardMapper.getList();    // json 데이터 형식으로 변환해서 리턴
    }
}
