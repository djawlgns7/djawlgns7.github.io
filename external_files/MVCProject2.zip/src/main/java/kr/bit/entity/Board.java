package kr.bit.entity;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Board {
    private int board_idx;
    private String board_title;
    private String board_content;
    private String board_writer;
    private String board_datetime;
    private int board_count;
}
