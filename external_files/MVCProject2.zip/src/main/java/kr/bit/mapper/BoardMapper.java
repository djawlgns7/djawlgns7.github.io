package kr.bit.mapper;

import kr.bit.entity.Board;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface BoardMapper {
    public List<Board> getList();

    public void insertBoard(Board board);

    public Board getBoard(int idx);

    public void deleteBoard(int idx);

    public void updateBoard(Board board);

    @Update("update bitboard set count = count + 1 where board_idx = #{board_idx}")
    public void plusCount(int board_idx);
}
