package kr.bit.mapper;

import kr.bit.beans.Student;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface StudentMapper {
    @Select("select * from student order by student_id desc")
    List<Student> getList();

    @Select("select * from student where student_name like #{student_name} order by student_name asc")
    List<Student> searchStudent(String student_name);

    @Select("select * from student where student_id = #{student_id}")
    Student getStudent(int student_id);

    @Update("update student " +
            "set student_name = #{student_name}, student_address = #{student_address}, " +
            "student_college = #{student_college}, student_major = #{student_major} " +
            "where student_id = #{student_id}")
    void updateStudent(Student student);

    @Delete("delete from student where student_id = #{student_id}")
    void deleteStudent(int student_id);

    @Insert("insert into student(student_name, student_address, student_college, student_major)" +
            "values (#{student_name}, #{student_address}, #{student_college}, #{student_major})")
    void insertStudent(Student student);
}
