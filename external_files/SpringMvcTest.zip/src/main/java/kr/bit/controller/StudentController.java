package kr.bit.controller;

import kr.bit.beans.Student;
import kr.bit.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class StudentController {
    private final StudentService studentService;

    @GetMapping("/studentList")
    @ResponseBody
    public List<Student> studentList() {
        return studentService.getList();
    }

    @GetMapping("/searchStudent/{search_text}")
    @ResponseBody
    public List<Student> searchStudent(@PathVariable("search_text") String search_text) {
        return studentService.searchStudent(search_text);
    }

    @GetMapping("/studentDetail/{student_id}")
    @ResponseBody
    public Student studentDetail(@PathVariable("student_id") int student_id) {
        return studentService.getStudent(student_id);
    }

    @PutMapping("/updateStudent")
    @ResponseBody
    public int updateStudent(@RequestBody Student student) {
        return studentService.updateStudent(student);
    }

    @DeleteMapping("/deleteStudent/{student_id}")
    @ResponseBody
    public void deleteStudent(@PathVariable("student_id") int student_id) {
        studentService.deleteStudent(student_id);
    }

    @PutMapping("/insertStudent")
    @ResponseBody
    public void insertStudent(@RequestBody Student student) {
        studentService.insertStudent(student);
    }
}
