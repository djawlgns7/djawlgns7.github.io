package kr.bit.beans;

import lombok.Data;

@Data
public class Student {
    private int student_id;
    private String student_name;
    private String student_address;
    private String student_college;
    private String student_major;
}
