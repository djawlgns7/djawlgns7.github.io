package kr.bit.service;

import kr.bit.beans.Student;
import kr.bit.mapper.StudentMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentService {
    private final StudentMapper studentMapper;

    public List<Student> getList() {
        return studentMapper.getList();
    }

    public List<Student> searchStudent(String name) {
        String student_name = "%" + name + "%";

        return studentMapper.searchStudent(student_name);
    }

    public Student getStudent(int id) {
        return studentMapper.getStudent(id);
    }

    public int updateStudent(Student student) {
        studentMapper.updateStudent(student);

        return student.getStudent_id();
    }

    public void deleteStudent(int id) {
        studentMapper.deleteStudent(id);
    }

    public void insertStudent(Student student) {
        studentMapper.insertStudent(student);
    }
}
